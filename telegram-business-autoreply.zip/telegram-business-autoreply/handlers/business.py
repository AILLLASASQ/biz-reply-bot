from aiogram import Router, Bot, F
from aiogram.types import BusinessConnection, Message

import database as db

router = Router()


@router.business_connection()
async def on_connect(conn: BusinessConnection):
    """يُستدعى عند ربط/فصل/تعديل صلاحيات البوت مع حساب Business."""
    # دعم النسختين: rights.can_reply (الأحدث) أو can_reply مباشرة (الأقدم)
    rights = getattr(conn, "rights", None)
    if rights is not None:
        can_reply = bool(getattr(rights, "can_reply", False))
    else:
        can_reply = bool(getattr(conn, "can_reply", False))

    enabled = bool(conn.is_enabled) and can_reply
    await db.save_connection(conn.user.id, conn.id, enabled)


@router.business_message(F.text)
async def on_message(message: Message, bot: Bot):
    """يرد تلقائياً على رسائل الزبائن نيابةً عن صاحب الحساب."""
    # تجاهل رسائل البوتات لمنع الحلقات
    if message.from_user and message.from_user.is_bot:
        return

    conn_id = message.business_connection_id
    if not conn_id:
        return

    owner_id = await db.get_owner(conn_id)
    if not owner_id:
        return

    # لا ترد على رسائل صاحب الحساب نفسه (الصادرة منه)
    if message.from_user and str(message.from_user.id) == str(owner_id):
        return

    if not await db.is_enabled(owner_id):
        return

    text = message.text.lower().strip()
    rules = await db.get_rules(owner_id)

    for rule in rules:
        kw = (rule.get("keyword") or "").lower().strip()
        if not kw:
            continue
        if rule.get("match_type") == "exact":
            hit = text == kw
        else:
            hit = kw in text
        if hit:
            await bot.send_message(
                chat_id=message.chat.id,
                text=rule["reply"],
                business_connection_id=conn_id,
            )
            break
